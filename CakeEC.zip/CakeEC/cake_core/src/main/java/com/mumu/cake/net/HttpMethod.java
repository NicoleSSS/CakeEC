package com.mumu.cake.net;

/**
 * @ClassName: HttpMethod
 * @Description: 描述
 * @Author: 范琳琳
 * @CreateDate: 2019/3/11 10:10
 * @Version: 1.0
 */
public enum HttpMethod {
    GET,
    POST,
    POST_RAW,
    PUT,
    PUT_RAW,
    DELETE,
    UOLOAD

}
