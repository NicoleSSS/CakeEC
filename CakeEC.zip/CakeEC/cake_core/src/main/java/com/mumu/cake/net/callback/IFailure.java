package com.mumu.cake.net.callback;

/**
 * @ClassName: IFailure
 * @Description: 失败回调
 * @Author: 范琳琳
 * @CreateDate: 2019/3/11 10:46
 * @Version: 1.0
 */
public interface IFailure {

    void onFailure();
}
