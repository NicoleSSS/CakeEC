package com.mumu.cake.activities;

import android.os.Bundle;
import android.widget.FrameLayout;

import com.mumu.cake.R;
import com.mumu.cake.delegates.CakeDelegate;

import androidx.annotation.Nullable;
import me.yokeyword.fragmentation.SupportActivity;

/**
 * @ClassName: ProxyActivity
 * @Description: 描述
 * @Author: 范琳琳
 * @CreateDate: 2019/3/10 23:17
 * @Version: 1.0
 */
public abstract class ProxyActivity extends SupportActivity {

    public abstract CakeDelegate setRootDelegate();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initContainer(savedInstanceState);
    }

    private void initContainer(@Nullable Bundle savedInstanceState){
        final FrameLayout container = new FrameLayout(this);
        container.setId(R.id.delegate_container);
        setContentView(container);
        if(savedInstanceState == null){
            loadRootFragment(R.id.delegate_container, setRootDelegate());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //资源回收
        System.gc();
        System.runFinalization();
    }
}
