package com.mumu.cake.app;

import android.content.Context;

import java.util.HashMap;
import java.util.WeakHashMap;

/**
 * @ClassName: Cake
 * @Description: 描述
 * @Author: 范琳琳
 * @CreateDate: 2019/3/10 22:15
 * @Version: 1.0
 */
public final class Cake {

    public static Configurator init(Context context){
        getConfigurations().put(ConfigType.APPLICATION_CONTEXT.name(), context.getApplicationContext());
        return Configurator.getInstance();
    }

    public static WeakHashMap<String, Object> getConfigurations(){
        return Configurator.getInstance().getMumuConfigs();
    }

    public static Context getApplication(){
        return  (Context) getConfigurations().get(ConfigType.APPLICATION_CONTEXT.name());
    }

}
