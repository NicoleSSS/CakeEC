package com.mumu.cake.app;

/**
 * @ClassName: ConfigType
 * @Description: 单例模式
 * @Author: 范琳琳
 * @CreateDate: 2019/3/10 22:19
 * @Version: 1.0
 */
public enum ConfigType {
    /**配置网络请求的域名*/
    API_HOST,

    /**全局上下文*/
    APPLICATION_CONTEXT,
    /**控制初始化的完成情况*/
    CONFIG_READY,
    /**字体的初始化项目*/
    ICON
}
